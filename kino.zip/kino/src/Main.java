import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Film {
    private String nazevFilmu;
    private String pristupnost;
    private String jmenoRezisera;
    private boolean podpora3D;

    public Film(String nazevFilmu, String pristupnost, String jmenoRezisera, boolean podpora3D) {
        this.nazevFilmu = nazevFilmu;
        this.pristupnost = pristupnost;
        this.jmenoRezisera = jmenoRezisera;
        this.podpora3D = podpora3D;
    }

    public String getNazevFilmu() {
        return nazevFilmu;
    }

    @Override
    public String toString() {
        return "Film: " + nazevFilmu + ", Režisér: " + jmenoRezisera;
    }
}

class Sala {
    private int cisloSalu;
    private int pocetRad;
    private int pocetKreselVRade;
    private List<Film> filmy;
    private boolean podpora3D;
    private boolean[][] kresla;

    public Sala(int cisloSalu, int pocetRad, int pocetKreselVRade, boolean podpora3D) {
        this.cisloSalu = cisloSalu;
        this.pocetRad = pocetRad;
        this.pocetKreselVRade = pocetKreselVRade;
        this.filmy = new ArrayList<>();
        this.podpora3D = podpora3D;
        this.kresla = new boolean[pocetRad][pocetKreselVRade];
    }

    public void pridatFilm(Film film) {
        filmy.add(film);
    }

    public int getCisloSalu() {
        return cisloSalu;
    }

    public int getPocetRad() {
        return pocetRad;
    }

    public int getPocetKreselVRade() {
        return pocetKreselVRade;
    }

    public List<Film> getFilmy() {
        return filmy;
    }

    public boolean maVolnaSedadlo(int rada, int kreslo) {
        return !kresla[rada - 1][kreslo - 1];
    }

    public void rezervovatSedadlo(int rada, int kreslo) {
        kresla[rada - 1][kreslo - 1] = true;
    }

    public void zrusitRezervaci(int rada, int kreslo) {
        kresla[rada - 1][kreslo - 1] = false;
    }
}

class NevyhodnyVyberFilmuException extends Exception {
    public NevyhodnyVyberFilmuException(String message) {
        super(message);
    }
}

class NevyhodnyVyberSaluException extends Exception {
    public NevyhodnyVyberSaluException(String message) {
        super(message);
    }
}

class NevyhodnyVyberKreslaException extends Exception {
    public NevyhodnyVyberKreslaException(String message) {
        super(message);
    }
}

public class Main {
    public static void main(String[] args) {
        // Vytvoření filmů
        Film film1 = new Film("Avatar", "PG-13", "James Cameron", true);
        Film film2 = new Film("Hledá se Nemo", "G", "Andrew Stanton", true);
        Film film3 = new Film("Pán prstenů: Společenstvo prstenu", "PG-13", "Peter Jackson", false);
        Film film4 = new Film("Gladiátor", "R", "Ridley Scott", false);

        // Vytvoření sálů
        Sala sala1 = new Sala(1, 10, 20, true);
        Sala sala2 = new Sala(2, 8, 18, false);

        // Přidání filmů do sálů
        sala1.pridatFilm(film1);
        sala1.pridatFilm(film2);
        sala1.pridatFilm(film3);
        sala2.pridatFilm(film3);
        sala2.pridatFilm(film4);

        Scanner scanner = new Scanner(System.in);

        // Výpis dostupných filmů a výběr filmu uživatelem
        System.out.println("Dostupné filmy:");
        for (int i = 0; i < sala1.getFilmy().size(); i++) {
            System.out.println((i + 1) + ". " + sala1.getFilmy().get(i));
        }
        System.out.print("Vyberte film (číslo): ");
        int vybranyFilmIndex = scanner.nextInt();

        if (vybranyFilmIndex < 1 || vybranyFilmIndex > sala1.getFilmy().size()) {
            System.out.println("Neplatný výběr filmu.");
            return;
        }

        Film vybranyFilm = sala1.getFilmy().get(vybranyFilmIndex - 1);

        // Výpis dostupných sálů pro vybraný film a výběr sálu uživatelem
        System.out.println("Dostupné sály pro film " + vybranyFilm.getNazevFilmu() + ":");
        for (int i = 1; i <= 2; i++) {
            System.out.println("Sál " + i + " (" + (sala1.getPocetRad() * sala1.getPocetKreselVRade()) + " míst)");
        }
        System.out.print("Vyberte sál (číslo): ");
        int vybranySalIndex = scanner.nextInt();

        if (vybranySalIndex != 1 && vybranySalIndex != 2) {
            System.out.println("Neplatný výběr sálu.");
            return;
        }

        Sala vybranySal = vybranySalIndex == 1 ? sala1 : sala2;

        // Výpis rozložení křesel v sále a výběr křesla uživatelem
        System.out.println("Rozložení křesel v sále " + vybranySal.getCisloSalu() + ":");
        for (int i = 1; i <= vybranySal.getPocetRad(); i++) {
            for (int j = 1; j <= vybranySal.getPocetKreselVRade(); j++) {
                if (vybranySal.maVolnaSedadlo(i, j))
                    if (vybranySal.maVolnaSedadlo(i, j)) {
                        System.out.print("O ");
                    } else {
                        System.out.print("X ");
                    }
            }
            System.out.println();
        }

        System.out.print("Vyberte řadu (1-" + vybranySal.getPocetRad() + "): ");
        int vybranaRada = scanner.nextInt();

        if (vybranaRada < 1 || vybranaRada > vybranySal.getPocetRad()) {
            System.out.println("Neplatný výběr řady.");
            return;
        }

        System.out.print("Vyberte křeslo (1-" + vybranySal.getPocetKreselVRade() + "): ");
        int vybraneKreslo = scanner.nextInt();

        if (vybraneKreslo < 1 || vybraneKreslo > vybranySal.getPocetKreselVRade()) {
            System.out.println("Neplatný výběr křesla.");
            return;
        }

        int rada = vybranaRada;
        int kreslo = vybraneKreslo;

        try {
            if (vybranySal.maVolnaSedadlo(rada, kreslo)) {
                vybranySal.rezervovatSedadlo(rada, kreslo);
                System.out.println("Rezervace úspěšně dokončena pro film " + vybranyFilm.getNazevFilmu() + " v sále " + vybranySal.getCisloSalu() + ", řada " + rada + ", křeslo " + kreslo + ".");
            } else {
                throw new NevyhodnyVyberKreslaException("Vybrané křeslo je již obsazeno.");
            }
        } catch (NevyhodnyVyberKreslaException e) {
            System.out.println("Chyba při rezervaci: " + e.getMessage());
        }
    }
}

